package com.example.backendcloudservice.eception;

public class InputData extends RuntimeException{
    public InputData(String msg) {
        super(msg);
    }
}
