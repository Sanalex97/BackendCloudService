package com.example.backendcloudservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendCloudServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendCloudServiceApplication.class, args);
    }

}
