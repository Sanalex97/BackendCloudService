package com.example.backendcloudservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCloudServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
